import subprocess, shutil, os

class Blocker:
    def __init__(self, dry_run=True, use_ufw=True):
        self.dry_run = dry_run
        self.use_ufw = use_ufw and shutil.which('ufw') is not None

    def block_ip(self, ip):
        try:
            if self.dry_run:
                print(f"[DRY-RUN] Would block: {ip}")
                return True
            if self.use_ufw:
                subprocess.run(['sudo','ufw','deny','from',ip], check=True)
            else:
                subprocess.run(['/sbin/iptables','-A','INPUT','-s',ip,'-j','DROP'], check=True)
            return True
        except Exception as e:
            print('Block failed:', e)
            return False

    def unblock_ip(self, ip):
        try:
            if self.dry_run:
                print(f"[DRY-RUN] Would unblock: {ip}")
                return True
            if self.use_ufw:
                subprocess.run(['sudo','ufw','delete','deny','from',ip], check=True)
            else:
                subprocess.run(['/sbin/iptables','-D','INPUT','-s',ip,'-j','DROP'], check=True)
            return True
        except Exception as e:
            print('Unblock failed:', e)
            return False
