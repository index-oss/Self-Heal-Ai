# SelfHeal-AI (Full Prototype)
This ZIP contains a full prototype of SelfHeal-AI including:
- Log monitoring
- Anomaly detection (fallback heuristic + optional model)
- VirusTotal & Zscaler integration (stubs)
- IP blocking (ufw/iptables)
- Self-healing & health checks (fwupd, apt)
- Multi-channel alerts (Telegram, Discord, Email)

## Quick start (demo)
1. Unzip the package.
2. Edit `config.yaml` and set at minimum `telegram_bot_token` and `telegram_chat_id`.
3. Ensure you have Python 3.8+ and create a venv:
   ```
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
4. For a demo without root actions, keep `dry_run: true` in config.yaml.
5. Create demo log file:
   ```
   mkdir -p logs configs
   echo "Sep 18 00:00:00 test sshd[12345]: Failed password for invalid user root from 1.2.3.4 port 5555" >> logs/demo_auth.log
   ```
6. Run:
   ```
   python3 main.py
   ```
7. To test blocker/action, set `dry_run: false` and run on an environment where you have sudo or use a VM.

## Notes
- Zscaler integration is a placeholder; implement according to your enterprise contract.
- The anomaly detector uses a simple heuristic unless you train & provide a model at `core/model.pkl`.
- Keep config.yaml permissions restricted (chmod 600).
