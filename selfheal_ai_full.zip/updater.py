import subprocess, time
class HealthChecker:
    def __init__(self, notifier, cfg):
        self.notifier = notifier
        self.cfg = cfg

    def check_firmware(self):
        try:
            r = subprocess.run(['fwupdmgr','get-updates'], capture_output=True, text=True, timeout=30)
            out = r.stdout.strip()
            if out and 'No updates' not in out:
                self.notifier.notify('[Health] Firmware updates available:\n' + out)
        except Exception as e:
            print('fwupd check failed', e)

    def check_security_updates(self):
        try:
            subprocess.run(['sudo','apt','update'], check=True, capture_output=True, text=True, timeout=120)
            r = subprocess.run(['apt','list','--upgradable'], capture_output=True, text=True)
            upgrades = [l for l in r.stdout.splitlines() if l and ('security' in l.lower() or 'ubuntu' in l.lower())]
            if upgrades:
                self.notifier.notify('[Health] Security upgrades available:\n' + '\n'.join(upgrades))
        except Exception as e:
            print('apt check failed', e)

    def run_checks(self):
        self.check_firmware()
        self.check_security_updates()
