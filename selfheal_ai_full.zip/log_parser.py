import time, os

class LogMonitor:
    def __init__(self, logfile, callback, poll_interval=2):
        self.logfile = logfile
        self.callback = callback
        self.poll_interval = poll_interval
        self._position = 0

    def _ensure_file(self):
        # create if missing for demo
        if not os.path.exists(self.logfile):
            open(self.logfile, 'a').close()

    def run(self):
        self._ensure_file()
        with open(self.logfile, 'r', errors='ignore') as f:
            f.seek(0, os.SEEK_END)
            self._position = f.tell()
        while True:
            try:
                with open(self.logfile, 'r', errors='ignore') as f:
                    f.seek(self._position)
                    lines = f.read().splitlines()
                    if lines:
                        for line in lines:
                            self.callback(line)
                        self._position = f.tell()
            except Exception as e:
                print('LogMonitor error:', e)
            time.sleep(self.poll_interval)
