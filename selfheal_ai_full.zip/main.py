#!/usr/bin/env python3
"""Entry point for SelfHeal-AI prototype (demo + deployment-ready).
This is a minimal orchestration script that ties together components.
For production use, run under python venv and systemd.
"""
import time
import threading
from log_parser import LogMonitor
from anomaly_ai import AnomalyDetector
from ip_blocker import Blocker
from healer import Healer
from alert import Notifier
from vt_api import VirusTotal
from zs_api import Zscaler
import yaml
import os, sys

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.yaml")
with open(CONFIG_PATH) as f:
    cfg = yaml.safe_load(f)

notifier = Notifier(cfg.get('telegram_bot_token'), cfg.get('telegram_chat_id'),
                    cfg.get('discord_webhook'), cfg.get('email'))
vt = VirusTotal(cfg.get('virustotal_api_key'), cache_ttl=cfg.get('vt_cache_ttl', 3600))
zs = Zscaler(cfg.get('zscaler_api_key')) if cfg.get('zscaler_api_key') else None
detector = AnomalyDetector(cfg.get('model_path'))
blocker = Blocker(dry_run=cfg.get('dry_run', True), use_ufw=cfg.get('use_ufw', True))
healer = Healer(service=cfg.get('web_service', 'apache2'), notifier=notifier)

def handle_log(line):
    # Basic parsing: try to extract IP and event
    ip = None
    try:
        parts = line.split()
        # crude: first token or token containing IP
        for p in parts:
            if p.count('.') >= 3:
                ip = p.strip('":,[]()')
                break
    except Exception:
        pass

    # Enrich and detect
    features = detector.extract_features(line, ip)
    is_anom, score = detector.is_anomaly(features)
    reason = []
    if is_anom:
        reason.append(f"AI score={score:.3f}")

    # Threat intelligence checks
    vt_result = None
    zs_result = None
    if ip:
        try:
            vt_result = vt.check_ip(ip)
            if vt_result and vt_result.get('malicious'):
                reason.append('VirusTotal')
        except Exception as e:
            notifier.notify(f"VT check failed: {e}")
        if zs:
            try:
                zs_result = zs.check_ip(ip)
                if zs_result and zs_result.get('malicious'):
                    reason.append('Zscaler')
            except Exception as e:
                notifier.notify(f"Zscaler check failed: {e}")

    if is_anom or (vt_result and vt_result.get('malicious')) or (zs_result and zs_result.get('malicious')):
        # final decision: block unless whitelisted
        wl = open(cfg.get('whitelist_path', 'configs/whitelist.txt')).read().splitlines()
        if ip and ip not in wl:
            blocked = blocker.block_ip(ip)
            notifier.notify(f"Blocked IP: {ip} (blocked={blocked})\nReason: {', '.join(reason)}\nLine: {line}")
            healer.record_action(f"Blocked {ip} due to {', '.join(reason)}")

def start_monitor_threads():
    monitors = []
    for path in cfg.get('monitor_paths', ['/var/log/auth.log']):
        m = LogMonitor(path, handle_log, poll_interval=cfg.get('poll_interval', 2))
        t = threading.Thread(target=m.run, daemon=True)
        t.start()
        monitors.append(t)
    return monitors

if __name__ == '__main__':
    print("[+] Starting SelfHeal-AI prototype")
    # start monitors
    threads = start_monitor_threads()
    # periodic health checks
    def health_loop():
        from updater import HealthChecker
        hc = HealthChecker(notifier, cfg)
        while True:
            try:
                hc.run_checks()
            except Exception as e:
                notifier.notify(f"Health check failed: {e}")
            time.sleep(cfg.get('healthcheck_interval', 3600))

    t2 = threading.Thread(target=health_loop, daemon=True)
    t2.start()

    # simple main loop
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("[+] Exiting")