import requests, time
class VirusTotal:
    def __init__(self, api_key=None, cache_ttl=3600):
        self.api_key = api_key
        self.cache = {}
        self.cache_ttl = cache_ttl

    def check_ip(self, ip):
        if not self.api_key:
            return None
        now = time.time()
        if ip in self.cache and now - self.cache[ip]['t'] < self.cache_ttl:
            return self.cache[ip]['r']
        url = f"https://www.virustotal.com/api/v3/ip_addresses/{ip}"
        headers = {'x-apikey': self.api_key}
        try:
            r = requests.get(url, headers=headers, timeout=10)
            if r.status_code == 200:
                data = r.json()
                stats = data.get('data',{}).get('attributes',{}).get('last_analysis_stats',{})
                malicious = (stats.get('malicious',0) + stats.get('suspicious',0)) > 0
                res = {'malicious': malicious, 'stats': stats}
                self.cache[ip] = {'t': now, 'r': res}
                return res
        except Exception as e:
            print('VT API error', e)
        return None
