import subprocess, time, os

class Healer:
    def __init__(self, service='apache2', notifier=None):
        self.service = service
        self.notifier = notifier

    def is_service_alive(self):
        try:
            return subprocess.call(['systemctl','is-active','--quiet', self.service]) == 0
        except Exception:
            return False

    def restart_service(self, service=None):
        svc = service or self.service
        try:
            subprocess.run(['sudo','systemctl','restart',svc], check=True)
            if self.notifier:
                self.notifier.notify(f"[Healer] Restarted {svc}")
            return True
        except Exception as e:
            if self.notifier:
                self.notifier.notify(f"[Healer] Failed restart {svc}: {e}")
            return False

    def record_action(self, msg):
        # append to logs/actions.log
        d = os.path.join(os.path.dirname(__file__), '..', 'logs')
        try:
            os.makedirs(d, exist_ok=True)
        except Exception:
            d = '/tmp'
        with open(os.path.join(d,'activity.log'), 'a') as f:
            f.write(f"{time.asctime()}: {msg}\n")
