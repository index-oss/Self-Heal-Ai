# Minimal anomaly detector: uses IsolationForest if model available,
# otherwise falls back to simple heuristic-based checks.
import joblib, os, numpy as np
from sklearn.ensemble import IsolationForest

class AnomalyDetector:
    def __init__(self, model_path=None):
        self.model_path = model_path or 'core/model.pkl'
        self.model = None
        if os.path.exists(self.model_path):
            try:
                self.model = joblib.load(self.model_path)
            except Exception:
                self.model = None

    def extract_features(self, log_line, ip=None):
        # Very small feature vector: length, count of digits, failed keyword
        length = len(log_line)
        digits = sum(c.isdigit() for c in log_line)
        failed = 1 if 'Failed password' in log_line or 'SQL' in log_line or 'error' in log_line.lower() else 0
        return [length, digits, failed]

    def is_anomaly(self, features):
        if self.model:
            try:
                res = self.model.predict([features])
                return (res[0] == -1, float(self.model.decision_function([features])[0]))
            except Exception:
                pass
        # fallback heuristic: many digits + failed token -> anomaly
        score = features[1] / (features[0] + 1)
        is_anom = features[2] == 1 and score > 0.05
        return is_anom, score
