import requests, smtplib, os
from email.message import EmailMessage

class Notifier:
    def __init__(self, telegram_token=None, telegram_chat_id=None, discord_webhook=None, email_cfg=None):
        self.tok = telegram_token
        self.chat = telegram_chat_id
        self.discord = discord_webhook
        self.email_cfg = email_cfg

    def notify(self, message):
        print('[NOTIFY]', message)
        if self.tok and self.chat:
            try:
                url = f"https://api.telegram.org/bot{self.tok}/sendMessage"
                requests.post(url, data={'chat_id': self.chat, 'text': message}, timeout=5)
            except Exception as e:
                print('Telegram notify failed:', e)
        if self.discord:
            try:
                requests.post(self.discord, json={'content': message}, timeout=5)
            except Exception as e:
                print('Discord notify failed:', e)
        if self.email_cfg:
            try:
                msg = EmailMessage()
                msg.set_content(message)
                msg['Subject'] = 'SelfHeal-AI Alert'
                msg['From'] = self.email_cfg.get('from')
                msg['To'] = self.email_cfg.get('to')
                s = smtplib.SMTP(self.email_cfg.get('smtp_server','localhost'))
                s.send_message(msg)
                s.quit()
            except Exception as e:
                print('Email notify failed:', e)
